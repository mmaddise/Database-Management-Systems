import MySQLdb.cursors
import mysql.connector
from mysql.connector import errorcode
try:
   reservationConnection = mysql.connector.connect(
      user='root',
      password='Poornavasu',
      host='localhost',
      database='ehr')

except mysql.connector.Error as exp:
   if exp.errno == errorcode.ER_ACCESS_DENIED_ERROR:
      print('unable to find the user with the given credentials')
   elif exp.errno == errorcode.ER_BAD_DB_ERROR:
      print('There is no database with the give name')
   else:
      print('unable to connect to the database:', exp)


cursor_new=reservationConnection.cursor()


try:
   insertion=cursor_new.callproc('insert_newpatientdetails',[101,'Priyam','K','Male','2428 MGR street Tirupathi','1997-07-27','9604435866','India','priyam1@gmail.com',404])
   reservationConnection.commit()
except:
   print("=======error=======")


try:
   insert=cursor_new.callproc('insert_newpatientdetails',[121,'Priyam','K','Male','2428 MGR street Tirupathi','1997-07-27',
'9604435866','India','priyam1@gmail.com',404])
   cursor_new.execute(insert)
   reservationConnection.commit()
except:
   print("error")


cursor_new.callproc('patientdetails_display')
for result in cursor_new.stored_results():
    details=result.fetchall()
for det in details:
    print(det)


cursor_new.callproc('Deletepatientdetails',[102])
print('\n')
print("patient details deleted")


for result in cursor_new.stored_results():
    details=result.fetchall()
for data in details:
    print(data)



update=cursor_new.Updatediagnose( 'Updatediagnose',['Normal fever and stomach pain','Dollo',75,103,'2022-12-24 10:30:00'])


print("  ")