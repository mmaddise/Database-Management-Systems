/* drop database ehr; */

create database ehr;

use ehr;

   /* insurancecoverdetails start */
    
    CREATE TABLE insurancecoverdetails (
  insurance_regnumber INT NOT NULL,
  insurance_name VARCHAR(100) NOT NULL,
  insurance_address VARCHAR(200) NOT NULL,
  insurance_contanctno VARCHAR(45) NOT NULL,
  insurance_mailid VARCHAR(50) NOT NULL,
  PRIMARY KEY (insurance_regnumber));
  
  
  /* drop table insurancecoverdetails */
  
   /* insurancedetails Start */
    
    CREATE TABLE insurancedetails (
  insurance_id INT NOT NULL,
  insurance_regnumber INT NOT NULL,
  policyno INT NOT NULL unique,
  effectivedate DATE NOT NULL,
  copay INT NOT NULL,
  deductibleperevent INT NOT NULL,
  totalcoverageamount INT NOT NULL,
  PRIMARY KEY (insurance_id),
  CONSTRAINT insurance_regnumber FOREIGN KEY (insurance_regnumber)
  REFERENCES insurancecoverdetails (insurance_regnumber)
    ON DELETE CASCADE
    ON UPDATE CASCADE);
    
    /* drop table insurancedetails */
    
    /* insurancedetails End */
    
    /* Patiendetails start */

CREATE TABLE patientdetails (
  pat_id INT NOT NULL,
  first_name VARCHAR(100) NOT NULL,
  last_name VARCHAR(100) NOT NULL,
  gender VARCHAR(45) NOT NULL,
  address VARCHAR(300) NOT NULL,
  dob DATE NOT NULL,
  phone_no VARCHAR(45) NOT NULL unique,
  nationality VARCHAR(45) NOT NULL,
  mailid VARCHAR(100) NOT NULL unique,
  insurance_id int NOT NULL,
  PRIMARY KEY (pat_id),
   CONSTRAINT insurance_id FOREIGN KEY (insurance_id) REFERENCES insurancedetails (insurance_id)
    ON DELETE CASCADE
    ON UPDATE CASCADE);
  
  /* drop table patientdetails */
  
  /* patiendetails End */
  
    /* appointmentdetails start */
    
      CREATE TABLE appointmentdetails(
  apt_id INT NOT NULL,
  apt_created DATETIME NOT NULL,
  apt_date DATETIME NOT NULL,
  apt_desc VARCHAR(500) NOT NULL,
  emp_id INT NOT NULL,
  pat_id INT NOT NULL,
  PRIMARY KEY (apt_id),
  CONSTRAINT pat_id FOREIGN KEY (pat_id) REFERENCES patientdetails (pat_id)
    ON DELETE CASCADE
    ON UPDATE CASCADE);
    
    /* drop table appointmentdetails */
    
       /* clinicdetails start */
    
    CREATE TABLE clinicdetails (
  clinic_id INT NOT NULL,
  clinic_manager VARCHAR(100) NOT NULL,
  clinicphone_no VARCHAR(45) NOT NULL unique,
  receptionist_name VARCHAR(100) NOT NULL,
  receptionist_contanct VARCHAR(45) NOT NULL unique,
  PRIMARY KEY (clinic_id));
    
    /* clinicdetails End */
    
    /* doctordetails start */
    
    CREATE TABLE doctordetails (
  doctor_id INT NOT NULL,
  first_name VARCHAR(100) NOT NULL,
  last_name VARCHAR(100) NOT NULL,
  phone_no VARCHAR(45) NOT NULL unique,
  specialist VARCHAR(100) NOT NULL,
  clinic_id INT NOT NULL,
  PRIMARY KEY (doctor_id),
   CONSTRAINT clinic_id FOREIGN KEY (clinic_id)
    REFERENCES clinicdetails (clinic_id)
    ON DELETE CASCADE
    ON UPDATE CASCADE);
    
    /* doctordetails end */
    
    /* checkindetails start */
    
    CREATE TABLE checkindetails (
  checkin_id INT NOT NULL,
  apt_id INT NOT NULL,
  first_name VARCHAR(100) NOT NULL,
  last_name VARCHAR(100) NOT NULL,
  apt_date DATETIME NOT NULL,
  doctor_id INT NOT NULL,
  pat_id INT NOT NULL,
  waitingarea_no INT NOT NULL,
  PRIMARY KEY (checkin_id),
  CONSTRAINT apt_id FOREIGN KEY (apt_id)
  REFERENCES appointmentdetails (apt_id)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT doctor_id FOREIGN KEY (doctor_id)
    REFERENCES doctordetails (doctor_id)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT patient_id
    FOREIGN KEY (pat_id)
    REFERENCES patientdetails (pat_id)
    ON DELETE CASCADE
    ON UPDATE CASCADE);

    /* checkindetails End */
    
    /*examroomdetails start */
    
    CREATE TABLE examroomdetails (
    examroom_dataid INT NOT NULL,
  room_no INT NOT NULL,
  pat_id INT NOT NULL,
  height DECIMAL NOT NULL,
  weight DECIMAL NOT NULL,
  checkin_id INT NOT NULL,
  doctor_id INT NOT NULL,
  PRIMARY KEY (examroom_dataid),
  CONSTRAINT patientId FOREIGN KEY (pat_id)
    REFERENCES patientdetails (pat_id)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT checkinid
    FOREIGN KEY (checkin_id)
    REFERENCES checkindetails (checkin_id)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT doctorid
    FOREIGN KEY (doctor_id)
    REFERENCES doctordetails (doctor_id)
    ON DELETE CASCADE
    ON UPDATE CASCADE);
    
    /* drop table examroomdetails; */
    /* examroomdetails end */
    
    /* supplierdetails start */
    
    CREATE TABLE supplierdetails (
  supplier_id INT NOT NULL,
  supplier_company VARCHAR(200) NOT NULL,
  phone_no VARCHAR(45) NOT NULL unique,
  mail_id VARCHAR(50) NOT NULL unique,
  address VARCHAR(200) NOT NULL,
  PRIMARY KEY (supplier_id) );
    
    /* supplierdetails end */
    
    /*medicinedetails start */
    
    CREATE TABLE medicinedetails (
  med_id INT NOT NULL,
  med_name VARCHAR(100) NOT NULL,
  company VARCHAR(45) NOT NULL,
  quantity INT NOT NULL,
  production_date DATE NOT NULL,
  expiry_date DATE NOT NULL,
  country VARCHAR(45) NOT NULL,
  supplied_date DATETIME NOT NULL,
  supplier_id INT NOT NULL,
  PRIMARY KEY (med_id),
   CONSTRAINT supplier_id
    FOREIGN KEY (supplier_id)
    REFERENCES supplierdetails (supplier_id)
    ON DELETE CASCADE
    ON UPDATE CASCADE);
    
    /*medicinedetails end */
    
    /* labdetails start */
    
    CREATE TABLE labdetails (
  report_id INT NOT NULL,
  pat_id INT NOT NULL,
  test_type VARCHAR(45) NOT NULL,
  test_date DATE NOT NULL,
  test_result VARCHAR(200) NOT NULL,
  PRIMARY KEY (report_id),
  CONSTRAINT pat_IdNumber
    FOREIGN KEY (pat_id)
    REFERENCES patientdetails (pat_id)
    ON DELETE CASCADE
    ON UPDATE CASCADE);
    
    /* labdetails end */
    
    /* diagnosisdetails start */
    
    CREATE TABLE diagnosisdetails (
  diagnosis_id INT NOT NULL,
  doctor_id INT NOT NULL,
  report_id INT default null,
  pat_id INT NOT NULL,
  test VARCHAR(100) default null,
  signs VARCHAR(200) NOT NULL,
  symptoms VARCHAR(200) NOT NULL,
  procedure_followed VARCHAR(200) NOT NULL,
  PRIMARY KEY (diagnosis_id),
  CONSTRAINT doctorid_number
    FOREIGN KEY (doctor_id)
    REFERENCES doctordetails (doctor_id)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT report_IdNo
    FOREIGN KEY (report_id)
    REFERENCES labdetails (report_id)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT patid_number
    FOREIGN KEY (pat_id)
    REFERENCES patientdetails (pat_id)
    ON DELETE CASCADE
    ON UPDATE CASCADE);
    /* drop table diagnosisdetails; */
    /* diagnosisdetails end */
    
    /* Treatmentdetails start */
    
    CREATE TABLE treatmentdetails (
     treatment_id INT NOT NULL,
  pat_id INT NOT NULL,
  med_id INT NOT NULL,
  doctor_id INT NOT NULL,
  med_name VARCHAR(100) NOT NULL,
  med_usage VARCHAR(100) NOT NULL,
   PRIMARY KEY ( treatment_id),
  CONSTRAINT patient_IdNum
    FOREIGN KEY (pat_id)
    REFERENCES patientdetails (pat_id)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT medicine_id
    FOREIGN KEY (med_id)
    REFERENCES medicinedetails (med_id)
    ON DELETE CASCADE
    ON UPDATE CASCADE, 
    CONSTRAINT doctorid_numberdata
    FOREIGN KEY (doctor_id)
    REFERENCES doctordetails (doctor_id)
    ON DELETE CASCADE
    ON UPDATE CASCADE);
    
    /* drop table treatmentdetails */
    
    /* treatmentdetails end */
    
    /* patinetsummarydetails start */
    
    CREATE TABLE patientsummarydetails (
  patient_summarydetid INT NOT NULL,
  pat_id INT NOT NULL,
  diagnosis_id INT NOT NULL,
  diagnose VARCHAR(200) NOT NULL,
  doctor_id INT NOT NULL,
  PRIMARY KEY (patient_summarydetid),
  CONSTRAINT patient_IdNo
    FOREIGN KEY (pat_id)
    REFERENCES patientdetails (pat_id)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT diagnosis_id
    FOREIGN KEY (diagnosis_id)
    REFERENCES diagnosisdetails (diagnosis_id)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT doctor_IdNo
    FOREIGN KEY (doctor_id)
    REFERENCES doctordetails (doctor_id)
    ON DELETE CASCADE
    ON UPDATE CASCADE);
    
    /* patinetsummarydetails end */
    
    /* visithistorydetails start */
    
    CREATE TABLE visithistorydetails (
  history_id INT NOT NULL,
  pat_id INT NOT NULL,
  doctor_id INT NOT NULL,
  apt_id INT NOT NULL,
  diagnosis_id INT NOT NULL,
  PRIMARY KEY (history_id),
   CONSTRAINT patientIdNo
    FOREIGN KEY (pat_id)
    REFERENCES patientdetails (pat_id)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT doctorIdNo
    FOREIGN KEY (doctor_id)
    REFERENCES doctordetails (doctor_id)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT aptIdNo
    FOREIGN KEY (apt_id)
    REFERENCES appointmentdetails (apt_id)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT diagnosisIdNo
    FOREIGN KEY (diagnosis_id)
    REFERENCES diagnosisdetails (diagnosis_id)
    ON DELETE CASCADE
    ON UPDATE CASCADE);
    
    /* visithistorydetails end */

