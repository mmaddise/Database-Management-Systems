
/*create view vw_patdiagnose_data 
  as
  select distinct ch.pat_id,ch.apt_date,ch.first_name,
ch.last_name,pat.diagnose,doc.first_name from 
patientdetails patdet join
checkindetails ch on patdet.pat_id=ch.pat_id
join patientsummarydetails pat on pat.pat_id=ch.pat_id join 
doctordetails doc on doc.doctor_id=pat.doctor_id order by ch.apt_date; */

/* select * from vw_patdiagnose_data */
/* patient diagnosis details start */

create view vw_patient_diagnosedetails
as
select pat.first_name,pat.last_name,pat.gender,pat.dob,pat.phone_no,da.signs,da.symptoms,pa.diagnose
from patientdetails pat join diagnosisdetails da on da.pat_id=pat.pat_id
join patientsummarydetails pa on pa.pat_id=pat.pat_id;

/* select * from vw_patient_diagnosedetails */ 

/* patient diagnosis details End */

/* Doctor details start */

create view vw_doctordetails
as
select first_name,last_name,phone_no,specialist from doctordetails;

/* select * from vw_doctordetails */

/* doctor details End */

/* medicine details start */

create view vw_medicineinfo
as 
select med_name,production_date,expiry_date from medicinedetails;

/* select * from vw_medicineinfo; */

/* medicine details end */

/* patient insurance details start */

create view vw_patient_insurancedetails
as
select pat.pat_id,pat.first_name,pat.last_name,pat.phone_no, pat.mailid,ins.copay,ins.deductibleperevent,
ins.totalcoverageamount,co.insurance_name,co.insurance_contanctno,co.insurance_mailid
from patientdetails pat join insurancedetails ins on ins.insurance_id=pat.insurance_id
join insurancecoverdetails co on co.insurance_regnumber=ins.insurance_regnumber;

/* select * from vw_patient_insurancedetails */

/* patient insurance details End */



 
 