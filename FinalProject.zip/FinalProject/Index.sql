/* INdex for patientdetails table */

create index  ix_patientdetails_mailid on patientdetails(first_name,last_name);

/* Index on doctordetails table */

create index  ix_doctordetails_name on doctordetails(first_name,last_name);

/* Index for checkindetails */

create index  ix_checkindetails_appointmentdate on checkindetails(apt_date);

/* show indexes from checkindetails */

/* Index for patientsummarydetails */

create index  ix_patientsummarydetails_diagnose on patientsummarydetails(diagnose);

/* show indexes from patientsummarydetails */

/* Index for medicinedetails */

create index  ix_medicinedetails_medicinename on medicinedetails(med_name);

/* Index for medicinedetails end */