/* new patinet insert Sp Start */
use ehr;
DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_newpatientdetails`(In pat_id int,
  IN first_name VARCHAR(100),
 IN  last_name VARCHAR(100),
  IN gender VARCHAR(45),
  IN address VARCHAR(300),
  IN datedetails DATE,
  IN phone_no VARCHAR(45),
  IN nationality VARCHAR(45),
  IN mailid VARCHAR(100),
  IN insurance_id int 
)
BEGIN
INSERT INTO patientdetails(pat_id, first_name, last_name, gender, address, dob, phone_no, nationality, mailid, insurance_id)
values(pat_id, first_name, last_name, gender, address, dob, phone_no, nationality, mailid, insurance_id);

select * from patientdetails;
END$$
DELIMITER ;

/* sample data 
call insert_newpatientdetails(121,'Priyam','K','Male','2428 MGR street Tirupathi','1997-07-27',
'9604435866','India','priyam1@gmail.com',404) ;
*/

/* new patinet insert Sp end */

/*patientdetails display start */


DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `patientdetails_display`()
BEGIN
select * from patientdetails;
END$$
DELIMITER ;

/* sample execution
 call patientdetails_display(); */
/* patientdetails display end */

/* patinetdetails update start */

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `patientdetails_update`(In patient_id int,
  IN pat_first_name VARCHAR(100),
 IN  pat_last_name VARCHAR(100),
  IN pat_gender VARCHAR(45))
BEGIN
update patientdetails set first_name=pat_first_name,last_name=pat_last_name,gender=pat_gender
where pat_id=patient_id;
END$$
DELIMITER ;

/* sample exection sscript
call patientdetails_update(103,'John','Bush','Male');  */

/* patientdetails update end */

/* Deleting the patinet details Start */

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `Deletepatientdetails`(IN patientId int)
BEGIN

delete from patientdetails where pat_id=patientId;

END$$
DELIMITER ;

/* sample data 
call Deletepatientdetails(121); */

/* Deleting the patinet details End */

/* Diaplaying patinet diagnosise details start */

/* DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `patdiagnose_doctor`()
BEGIN
select * from vw_patdiagnose_data ;
END$$
DELIMITER ; */

/* sample procedurecall 
call patdiagnose_doctor();
*/


/* Displaying patinet diagnosise details end */

/* Updating the diagnose details of patient  start */


DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `Updatediagnose`(IN Diagnose varchar(300),
IN medicinename VARCHAR(300), 
IN weight decimal,
IN patientId INT,
IN visiteddate datetime
)
BEGIN

update patientsummarydetails p join patientdetails pat on pat.pat_id=p.pat_id
join treatmentdetails t on  t.pat_id=p.pat_id join appointmentdetails apt on apt.pat_id=t.pat_id
join  examroomdetails e on e.pat_id=t.pat_id 
set  p.diagnose=Diagnose,t.med_name=medicinename,
e.weight=weight where pat.pat_id=patientId and apt.apt_date=visiteddate;

END$$
DELIMITER ;

/* call Updatediagnose('Normal fever and stomach pain','Dollo',75,103,'2022-12-24 10:30:00'); */
/* Updating the diagnose details of patient End */

/* select * from patientsummarydetails p join patientdetails pat on pat.pat_id=p.pat_id
join treatmentdetails t on  t.pat_id=p.pat_id join appointmentdetails apt on apt.pat_id=t.pat_id
join  examroomdetails e on e.pat_id=t.pat_id where pat.pat_id=103 and apt.apt_date='2022-12-24 10:30:00'; */

/* doctor insert start */

/*medicine details start */

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `medicinedetails_update`(IN medicineId int,
medicinename varchar(200),medicinequantity int
)
BEGIN
update medicinedetails set med_name=medicinename,quantity=medicinequantity
where med_id=medicineId;
END$$
DELIMITER ;

/* sample execution
call medicinedetails_update(7001,'Dollo_sp',5000); 

select * from medicinedetails; */

/* medicine delete */

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `medicine_delete`(in medicineId int)
BEGIN
delete from medicinedetails where med_id=medicineId;
END$$
DELIMITER ;

/* sample call 
call medicine_delete(7001);
select * from medicinedetails;
*/

/* medicine diaply */

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `medicine_diaplay`()
BEGIN
select * from medicinedetails;
END$$
DELIMITER ;

/* sample call 
call medicine_diaplay(); */










