use ehr;

/* insurancecoverdetails Start */

INSERT INTO insurancecoverdetails(insurance_regnumber, insurance_name, insurance_address, insurance_contanctno, insurance_mailid)
values(301,'PPO Travel Program by Blue','33122 Apt D concord','3265431278','blue@gmail.com'),
(302,'In Home Assistance by Blue','33122 Apt D concord','3265431278','blue@gmail.com'),
(303,'Internation Students by issso','33567 Apt c uptown','4556789102','isso@gmail.com'),
(304,'High schools students by isso','33567 Apt c uptown','4556789102','isso@gmail.com'),
(305,'Internation students by Blue','33122 Apt D concord','3265431278','blue@gmail.com');

/* select * from insurancecoverdetails */
/* insurancecoverdetails End */

/*Insurancedetails start */
INSERT INTO insurancedetails(insurance_id, insurance_regnumber, policyno, effectivedate, copay, deductibleperevent, totalcoverageamount)
VALUES(401,301,34567,'2022-08-01',500,50,700),
(402,303,34578,'2022-08-05',600,60,800),
(403,303,34589,'2022-08-01',600,60,800),
(404,305,34599,'2022-08-01',700,70,900),
(405,305,34587,'2022-08-01',700,70,900);

/* select * from insurancedetails */
/* Insurancedetails End */ 
/* patient details start */
INSERT INTO patientdetails(pat_id, first_name, last_name, gender, address, dob, phone_no, nationality, mailid,insurance_id)
values(101,'James','Scot','Male','111 APt A Mecklenburg','1996-10-22','9704444555','USA','james@gmail.com',404),
(102,'Mark','Potter','Male','2232 Apt D Timberbrook','1997-07-22','9804444666','UK','mark@gmail.com',401),
(103,'Jack','Jef','Male','5555 Apt H Arklow Rd','1994-08-25','7304343575','USA','jack@gmail.com',403),
(104,'Ooha','K','FeMale','2323 MGR street Tirupathi','1998-07-27','9604444888','India','ooha@gmail.com',404),
(105,'Divya','D','FeMale','2987 SJK street Vizag','1997-07-25','9404646857','India','divya@gmail.com',405);

/* select * from patientdetails */
/* patient details end */

/* appointmentdetails start */

INSERT INTO appointmentdetails(apt_id, apt_created, apt_date, apt_desc, emp_id, pat_id)
VALUES(20001,'2022-12-02 12:35:29.123','2022-12-24 12:30:00.000','Headache',201,101),
(20002,'2022-11-02 12:35:29.123','2022-12-24 10:30:00.000','Headache',201,103),
(20003,'2022-09-02 12:40:29.123','2022-09-02 11:30:00.000','Fever',202,102),
(20004,'2022-10-02 11:35:29.123','2022-10-02 12:30:00.000','Stomach pain',203,105),
(20005,'2022-10-02 10:35:29.123','2022-10-02 11:30:00.000','Stomach Pain',201,104),
(20006,'2022-12-02 08:35:29.123','2022-12-02 9:30:00.000','Stomach Pain',201,104),
(20007,'2022-12-04 08:35:29.123','2022-12-24 9:30:00.000','Stomach Pain',203,105);

/* select * from appointmentdetails ; */
/* appointmentdetails End */



/* clinicdetails start */

INSERT INTO clinicdetails(clinic_id, clinic_manager, clinicphone_no, receptionist_name, receptionist_contanct)
VALUES(30001,'Paul','9801112223','Sarah','97022233339'),
(30002,'Jimmy','9702221223','Clara','94044433338'),
(30003,'Nick','9603332223','Peter','96088833337'),
(30004,'Harry','9505552223','Micky','990666633339'),
(30005,'Henry','9707772223','Edward','91024236336');

/* select * from clinicdetails */

/* clinicdetails end */

/* doctordetails start */

INSERT INTO doctordetails(doctor_id, first_name, last_name, phone_no, specialist, clinic_id)
VALUES(40001,'Georgi','Facello','3003009001','Physician',30001),
(40002,'Chirstian','Koblick','4005007002','Physician',30001),
(40003,'Nithiya','Sharma','6005008007','Dermatologist',30001),
(40004,'Smitha','Raj','8009003008','Dermatologist',30001),
(40005,'Mary','Sluis','9002001003','Orthopedic',30001);

/* select * from doctordetails */

/* doctordetails end */

/* checkindetails start */

INSERT INTO checkindetails(checkin_id, apt_id, first_name, last_name, apt_date, doctor_id, pat_id, waitingarea_no)
VALUES(50001,20004,'Divya','D','2022-10-02 12:30:00.000',40001,105,2),
(50002,20005,'Ooha','K','2022-10-02 11:30:00.000',40001,104,2),
(50003,20003,'Mark','Potter','2022-09-02 11:30:00',40002,102,1),
(50004,20001,'James','Scot','2022-12-24 12:30:00',40004,101,4),
(50005,20002,'Jack','Jef','2022-12-24 10:30:00',40001,103,4),
(50006,20006,'Ooha','K','2022-10-02 11:30:00.000',40001,104,2);

INSERT INTO checkindetails(checkin_id, apt_id, first_name, last_name, apt_date, doctor_id, pat_id, waitingarea_no)
VALUES(50007,20007,'Divya','D','2022-12-24 09:30:00',40002,105,2);
/* select * from checkindetails;

select * from doctordetails;

select * from appointmentdetails; 

select * from patientdetails */
/*checkindetails end */

/* roommdetails start */

INSERT INTO examroomdetails(examroom_dataid,room_no, pat_id, height, weight, checkin_id, doctor_id)
values(1,101,105,6,55,50001,40001),
(2,101,104,5,65,50002,40001),
(3,103,102,5,45,50003,40002),
(4,107,101,6,55,50004,40004),
(5,102,103,6,75,50005,40001),
(6,101,104,5,65,50006,40001);
INSERT INTO examroomdetails(examroom_dataid,room_no, pat_id, height, weight, checkin_id, doctor_id)
values(7,105,105,5,65,50007,40002);
/* select * from examroomdetails ;*/

/* roomdetails end */

/* supplierdetails start */

INSERT INTO supplierdetails(supplier_id, supplier_company, phone_no, mail_id, address)
VALUES(6001,'People Health','9665552314','people@gmail.com','3567 APt D hills NC'),
(6002,'Chidren Health','9775552314','children@gmail.com','3967 APt D radio station NC'),
(6003,'Good Health','9668882314','good@gmail.com','3667 APt B new road NC'),
(6004,'Health Care','9765552314','health@gmail.com','4567 APt A concord NC'),
(6005,'Daylight','9335552314','day@gmail.com','3563 APt C hills Virginia');
/* select * from supplierdetails */
/* supplierdetails end */

/* medicinedetails start */

INSERT INTO medicinedetails(med_id, med_name, company, quantity, production_date, expiry_date, country, supplied_date, supplier_id)
VALUES(7001,'Dollo','People Health',2000,'2022-01-02','2024-10-02','India','2022-08-02 11:30:00.000','6001'),
(7002,'Paracetmol','Chidren Health',3000,'2022-02-02','2024-11-02','India','2022-07-02 11:30:00.000','6002'),
(7003,'meptalphase','Good Health',4000,'2022-03-02','2024-12-02','India','2022-06-02 11:30:00.000','6003'),
(7004,'Dollo','People Health',4000,'2022-01-02','2024-12-02','India','2022-08-10 11:30:00.000','6001'),
(7005,'NIzoral','Health Care',2000,'2022-02-05','2024-11-12','USA','2022-08-02 11:30:00.000','6004');

/* select * from medicinedetails */
/* medicinedetails end */

/* labdetails start */

INSERT INTO labdetails(report_id, pat_id, test_type, test_date, test_result)
VALUES(8001,102,'Tyroid','2022-12-24','Negative'),
(8003,103,'typhoid','2022-12-24','Negative'),
(8004,105,'Scan','2022-12-24','No Ulcer');

/* select * from labdetails;
   select * from doctordetails;
   select * from patientdetails;
   select * from appointmentdetails;
   select * from checkindetails;
   select * from medicinedetails;
   select * from diagnosisdetails;
   select * from patientsummarydetails;

 */
/* labdetails end */

/* diagnosisdetails start */

INSERT INTO diagnosisdetails(diagnosis_id, doctor_id, report_id, pat_id, test, signs, symptoms, procedure_followed)
VALUES(901,40002,8001,102,'Tyroid','Headche','Headche and fever','Follow prescription'),
(903,40001,8003,103,'typhoid','Headche','headche and fever','Follow prescription'),
(904,40001,8004,105,'Scan','Stomach pain','Stomach pain','Follow prescription');
INSERT INTO diagnosisdetails(diagnosis_id, doctor_id, pat_id, test, signs, symptoms, procedure_followed)
VALUES
(905,40001,104,'NA','Stomach Pain','Stomach Pain and fever','Follow prescription and followup checkup'),
(906,40004,101,'NA','Headache','Headache','Follow prescription');

INSERT INTO diagnosisdetails(diagnosis_id, doctor_id, pat_id, test, signs, symptoms, procedure_followed)
VALUES
(907,40001,104,'NA','Stomach Pain','Stomach Pain and Fever','Follow prescription'),
(908,40002,105,'NA','Stomach Pain','Stomach Pain and Headache','Follow prescription');

/* delete from diagnosisdetails where diagnosis_id in (905,906) */

/* select * from diagnosisdetails */
/* diagnosisdetails end */

/* treatmentdetails start */

INSERT INTO treatmentdetails(treatment_id,pat_id, med_id,doctor_id, med_name, med_usage)
VALUES(1,101,7001,40004,'Dollo','2 times a day'),
(2,103,7001,40001,'Dollo','2 times a day'),
(3,102,7002,40002,'Paracetmol','3 times a day'),
(4,105,7003,40001,'meptalphase','2 times a day'),
(5,104,7003,40001,'meptalphase','2 times a day'),
(6,104,7003,40001,'meptalphase','2 times a day as needed by pain'),
(7,105,7001,40002,'Dollo','2 times a day');
/* select * from treatmentdetails */

/* treatmentdetails end */

  /* patinetsummarydetails start */
  
  /* select * from diagnosisdetails */
  
  INSERT INTO patientsummarydetails (patient_summarydetid, pat_id, diagnosis_id, diagnose, doctor_id)
  VALUES(9001,101,906,'Normal Headache',40004),
  (9002,102,901,'Normal Headche',40002),
  (9003,103,903,'Normal fever',40001),
  (9004,104,905,'Normal Stomach Pain and fever',40001),
  (9005,104,907,'Normal Stomach Pain and fever',40001);

  INSERT INTO patientsummarydetails (patient_summarydetid, pat_id, diagnosis_id, diagnose, doctor_id)
  VALUES(9006,105,904,'Normal Stomach Pain and throat pain',40001);
  
  INSERT INTO patientsummarydetails (patient_summarydetid, pat_id, diagnosis_id, diagnose, doctor_id)
  VALUES(9007,105,908,'Normal Stomach Pain and Headache',40002);
  
  update patientsummarydetails set diagnose='Normal Stomach' where patient_summarydetid=9005;
  
  /* delete from patientsummarydetails where pat_id in(101,102,103,104,105) */

  /* patinetsummarydetails end */
  
   /* visithistorydetails start */
   INSERT INTO visithistorydetails(history_id, pat_id, doctor_id, apt_id, diagnosis_id)
   VALUES(500001,101,40004,20001,906),
   (500002,102,40002,20003,901),
   (500003,103,40001,20002,903),
   (500004,104,40001,20005,905),
   (500005,105,40004,20001,904),
   (500006,104,40001,20006,907),
   (500007,105,40001,20006,908);
   

   
   /* delete from visithistorydetails where pat_id in(101,102,103,104,105)
   
   select * from diagnosisdetails */
    /* visithistorydetails end */






